using UnityEngine;
using NWH.VehiclePhysics;

public class IRDSCarControllInputNWH : MonoBehaviour
{

    // cached reference for CarControl
    public VehicleController drivetrain;
    public IRDSCarControllInput carInputs;
    public IRDSCarControllerAI carAI;
    private float airDrag;
    public Transform[] frontWheels;

    public float[] kfriction = { 1, 1 };
    // Initialize
    void Awake()
    {
        if (drivetrain == null)
            drivetrain = GetComponent<VehicleController>();
        if (carInputs == null)
            carInputs = GetComponent<IRDSCarControllInput>();
        if (carAI == null)
            carAI = GetComponent<IRDSCarControllerAI>();
        //		airDrag = drivetrain.maxSpeed;
        carAI.SetFrictionExtaernalPhysics(kfriction);
        carInputs.SetTopSpeedExternalPhysics(150f);
        carAI.SetHFactorExternalPhysics(0.2f);
        carAI.SetClFactorExternalPhysics(0.3f);
        carAI.SetWingaFactorExternalPhysics(1f);
    }
    void Start()
    {
        drivetrain.Active = true;

        carAI.SetIRDSWheelsCenter(frontWheels);
        carAI.SetMaxSteerLockExternalPhysics(28);
        carInputs.gearRatiosLengthExternalPhysics = 3;
        carInputs.maxRpmExternalPhysics = 1000;
        carInputs.gearSpeedsExternalCarPhysics = new float[3];

    }


    void FixedUpdate()
    {
        if (!carInputs.GetCarPilot())
        {
            carController();
        }
        else
        {
            if (carAI.NavigateTWaypoints.GoPits)
                if (carInputs.GetCarSpeed() > IRDSWPManager.GetPitMaxSpeed())
                {
                    //No way to limit the car speed on RCC
                }
            if (carInputs.auto1 || carInputs.auto2 || carInputs.auto3)
                PlayerController();
            if (IRDSStatistics.GetCanRace())
            {
                drivetrain.Active = true;
            }
            else
            {
                drivetrain.Active = false;
            }
        }
    }

    void carController()
    {

        drivetrain.input.Horizontal = carInputs.GetSteerInput();
        drivetrain.input.Handbrake = carInputs.GetHandBrakeInput();

        if (IRDSStatistics.GetCanRace() || carAI.rollingStart)
        {
            if (carInputs.targetGearExtarnelPhysics - 1 < 1)
            {
                drivetrain.input.Vertical = -carInputs.GetThrottleInput();
            }
            else
            {
                drivetrain.input.Vertical = carInputs.GetThrottleInput();

            }
            drivetrain.input.Handbrake = carInputs.GetBrakeInput();
        }
        else
        {
            drivetrain.input.Vertical = 0;
            drivetrain.input.Handbrake = 1;
        }

    }

    void PlayerController()
    {

        if (carInputs.auto3)
            drivetrain.input.Vertical = carInputs.GetThrottleInput();
        else
        {

            if (Input.GetKey(KeyCode.UpArrow))
                drivetrain.input.Vertical += 0.05f;
            drivetrain.input.Vertical = Mathf.Clamp01(drivetrain.input.Vertical);
        }
        if (carInputs.auto1)
            drivetrain.input.Vertical = -carInputs.GetBrakeInput();
        else
        {

            if (Input.GetKey(KeyCode.DownArrow))
                drivetrain.input.Vertical -= 0.05f;
        }

        if (carInputs.auto2)
            drivetrain.input.Horizontal = carInputs.GetSteerInput();
        else
        {

            drivetrain.input.Horizontal = Mathf.Clamp(Input.GetAxis("Horizontal"), -1, 1);
            //			drivetrain.steerInput=Mathf.Clamp(drivetrain.steerInput,-1,1);
        }

        drivetrain.input.Handbrake = carInputs.GetHandBrakeInput();

        //		drivetrain.gearInput = carInputs.GetGearInput();
    }


    //end line
}