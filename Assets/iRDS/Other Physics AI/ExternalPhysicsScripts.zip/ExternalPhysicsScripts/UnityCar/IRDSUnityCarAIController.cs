using UnityEngine;
using System.Collections;

public class IRDSUnityCarAIController : CarController
{

    //Variables declaration for using it as Player Input, this is just for when AutoThrottle, AutoBrake or AutoSteering is enabled
    public string throttleAxis = "Throttle";
    public string brakeAxis = "Brake";
    public string steerAxis = "Horizontal";
    public string handbrakeAxis = "Handbrake";
    public string clutchAxis = "Clutch";
    public string shiftUpButton = "ShiftUp";
    public string shiftDownButton = "ShiftDown";
    public string startEngineButton = "StartEngine";
    public bool normalizeThrottleInput = false;
    public bool exponentialThrottleInput = false;
    public bool normalizeBrakesInput = false;
    public bool exponentialBrakesInput = false;
    public bool normalizeClutchInput = false;
    public bool exponentialClutchInput = false;
    //End of variable declaration for player Input


    IRDSCarControllInput carInputs;
    public void Awake()
    {
        //This is needed to get the IRDSCarControlInput Instance, do not delete
        carInputs = GetComponent<IRDSCarControllInput>();
    }


    protected override void GetInput(out float throttleInput,

                                    out float brakeInput,

                                    out float steerInput,

                                    out float handbrakeInput,

                                    out float clutchInput,

                                    out bool startEngineInput,

                                    out int targetGear)
    {








        //This if statement checks if autoTBrake (auto1) is enabled or if the car is AI controled (!GetCarPilot())
        if (carInputs.auto1 || !carInputs.GetCarPilot())
            brakeInput = carInputs.GetBrakeInput();
        else
            //If is human controlled this would be the assigned input, change this line bellow to assing the input to
            //The brakeInput that you may want
            brakeInput = Input.GetAxisRaw(brakeAxis);

        //This if statement checks if autoThrottle (auto3) is enabled or if the car is AI controled (!GetCarPilot())
        if (carInputs.auto3 || !carInputs.GetCarPilot())
        {
            if (!carInputs.auto1 && brakeInput != 0 && carInputs.GetCarPilot())
                throttleInput = 0;
            else
                throttleInput = carInputs.GetThrottleInput();
        }
        else
            //If is human controlled this would be the assigned input, change this line bellow to assing the input to
            //The throttleInput that you may want
            throttleInput = Input.GetAxisRaw(throttleAxis);


        //This if statement checks if autoSteering (auto2) is enabled or if the car is AI controled (!GetCarPilot())
        if (carInputs.auto2 || !carInputs.GetCarPilot())
            steerInput = carInputs.GetSteerInput();
        else
            //If is human controlled this would be the assigned input, change this line bellow to assing the input to
            //The steerInput that you may want
            steerInput = Input.GetAxisRaw(steerAxis);


        //Here we check if the car is Human Controled, and apply the input settings accordingly (this are the same as AxisController)
        if (carInputs.GetCarPilot())
        {
            //You can change this code bellow to fit your needs
            //***************************************************
            handbrakeInput = Input.GetAxisRaw(handbrakeAxis);
            clutchInput = Input.GetAxisRaw(clutchAxis);
            startEngineInput = Input.GetButton(startEngineButton);
            if (normalizeThrottleInput == true) throttleInput = (throttleInput + 1) / 2;
            if (exponentialThrottleInput == true) throttleInput *= throttleInput;
            if (normalizeBrakesInput == true) brakeInput = (brakeInput + 1) / 2;
            if (exponentialBrakesInput == true) brakeInput *= brakeInput;
            if (normalizeClutchInput == true) clutchInput = (clutchInput + 1) / 2;
            if (exponentialClutchInput == true) clutchInput *= clutchInput;
            //***************************************************
        }
        else
        {
            //If the car is AI controlled, then it would assign the following values to the handbrakeInput, clutchInput and startEngineInput
            //Do not change the code bellow
            //******************************************
            handbrakeInput = carInputs.GetHandBrakeInput();
            clutchInput = 0;
            startEngineInput = false;
            //******************************************
        }
        // Gear shift

        //Do not delete this line
        targetGear = drivetrain.gear;


        // Here we check if the car is autoThrottle and not automatic or if it is AI controlled
        // and then apply the gear shiftting accordingly by the AI script
        //Do not change these lines of code
        //********************************************************************************************************
        if ((carInputs.auto3 && !drivetrain.automatic) || !carInputs.GetCarPilot())
        {
            if (carInputs.targetGearExtarnelPhysics > targetGear)
            {
                ++targetGear;
                carInputs.targetGearExtarnelPhysics = (Mathf.Clamp(carInputs.targetGearExtarnelPhysics, 0, drivetrain.gearRatios.Length - 1));
            }
            if (carInputs.targetGearExtarnelPhysics < targetGear)
            {
                --targetGear;
                carInputs.targetGearExtarnelPhysics = (Mathf.Clamp(carInputs.targetGearExtarnelPhysics, 0, drivetrain.gearRatios.Length - 1));
            }
        }
        //********************************************************************************************************

        //If the car is human controlled or is not autoThrottle but any of the other two is enabled (autoSteer or autoBrake)
        // Then the human can shift gears if the car is not in automatic.

        else
        {
            //You can change the code bellow
            //*********************************************************************
            if (Input.GetButtonDown(shiftUpButton))
            {
                ++targetGear;
            }
            if (Input.GetButtonDown(shiftDownButton))
            {
                --targetGear;
            }

            if (drivetrain.shifter == true)
            {
                if (Input.GetButton("reverse"))
                {
                    targetGear = 0;
                }

                else if (Input.GetButton("neutral"))
                {
                    targetGear = 1;
                }

                else if (Input.GetButton("first"))
                {
                    targetGear = 2;
                }

                else if (Input.GetButton("second"))
                {
                    targetGear = 3;
                }

                else if (Input.GetButton("third"))
                {
                    targetGear = 4;
                }

                else if (Input.GetButton("fourth"))
                {
                    targetGear = 5;
                }

                else if (Input.GetButton("fifth"))
                {
                    targetGear = 6;
                }

                else if (Input.GetButton("sixth"))
                {
                    targetGear = 7;
                }

                else
                {
                    targetGear = 1;
                }
            }
            //*********************************************************************
        }
    }

}
