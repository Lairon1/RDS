using UnityEngine;

public class IRDSCarControllInputSBK : MonoBehaviour
{

    // cached reference for CarControl
    public controlHub drivetrain;

    public IRDSCarControllInput carInputs;
    public IRDSCarControllerAI carAI;
    private float airDrag;
    public Transform[] frontWheels;

    public float[] kfriction = { 1, 1 };
    // Initialize
    void Awake()
    {
        if (drivetrain == null)
            drivetrain = GetComponent<controlHub>();
        if (carInputs == null)
            carInputs = GetComponent<IRDSCarControllInput>();
        if (carAI == null)
            carAI = GetComponent<IRDSCarControllerAI>();
        //		airDrag = drivetrain.maxSpeed;
        carAI.SetFrictionExtaernalPhysics(kfriction);
        carInputs.SetTopSpeedExternalPhysics(150f);
        carAI.SetHFactorExternalPhysics(0.2f);
        carAI.SetClFactorExternalPhysics(0.3f);
        carAI.SetWingaFactorExternalPhysics(1f);
    }
    void Start()
    {
        carAI.SetIRDSWheelsCenter(frontWheels);
        carAI.SetMaxSteerLockExternalPhysics(28);
        carInputs.gearRatiosLengthExternalPhysics = 3;
        carInputs.maxRpmExternalPhysics = 1000;
        carInputs.gearSpeedsExternalCarPhysics = new float[3];
        carAI.OnRespawn += Respawn;
    }

    void Respawn()
    {
        drivetrain.fullRestartBike = true;
    }
    void FixedUpdate()
    {
        if (!carInputs.GetCarPilot())
        {
            carController();
        }
        else
        {
            if (carAI.NavigateTWaypoints.GoPits)
                if (carInputs.GetCarSpeed() > IRDSWPManager.GetPitMaxSpeed())
                {
                    //					drivetrain.maxSpeed =IRDSWPManager.GetPitMaxSpeed();
                }
            if (carInputs.auto1 || carInputs.auto2 || carInputs.auto3)
                PlayerController();
        }
    }

    void carController()
    {

        drivetrain.Horizontal = carInputs.GetSteerInput() * 2f;
        drivetrain.HorizontalMassShift = carInputs.GetSteerInput();
        drivetrain.rearBrakeOn = carInputs.GetHandBrakeInput() > 0 ? true : false;

        if (IRDSStatistics.GetCanRace() || carAI.rollingStart)
        {

            if (carInputs.targetGearExtarnelPhysics - 1 < 1)
            {
                drivetrain.reverse = true;
                drivetrain.Vertical = carInputs.GetThrottleInput();
            }
            else
            {
                drivetrain.reverse = false;
                drivetrain.Vertical = carInputs.GetThrottleInput();

            }
            if (carInputs.GetBrakeInput() != 0)
            {

                drivetrain.Vertical = -carInputs.GetBrakeInput();
            }

        }
        else
        {
            drivetrain.Vertical = 0;
            drivetrain.Vertical = -1;
        }

    }

    void PlayerController()
    {

        if (carInputs.auto3)
            drivetrain.Vertical = carInputs.GetThrottleInput();
        else
        {

            if (Input.GetKey(KeyCode.UpArrow))
                drivetrain.Vertical += 0.05f;
            drivetrain.Vertical = Mathf.Clamp01(drivetrain.Vertical);
        }
        if (carInputs.auto1)
            drivetrain.Vertical = carInputs.GetBrakeInput();
        else
        {

            if (Input.GetKey(KeyCode.DownArrow))
                drivetrain.Vertical -= 0.05f;
            drivetrain.Vertical = Mathf.Clamp01(drivetrain.Vertical);
        }

        if (carInputs.auto2)
            drivetrain.Horizontal = carInputs.GetSteerInput();
        else
        {

            drivetrain.Horizontal = Mathf.Clamp(Input.GetAxis("Horizontal"), -1, 1);
            //			drivetrain.steerInput=Mathf.Clamp(drivetrain.steerInput,-1,1);
        }
        drivetrain.rearBrakeOn = carInputs.GetHandBrakeInput() > 0 ? true : false;

        //		drivetrain.gearInput = carInputs.GetGearInput();
    }


    //end line
}